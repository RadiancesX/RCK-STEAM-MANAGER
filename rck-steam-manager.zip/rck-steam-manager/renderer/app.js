'use strict';
(() => {
  const api = window.api;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const MAX = 32; // Steam aynı anda en fazla 32 oyunu sayar
  const QR_HELP = 'Telefonundaki Steam uygulamasını aç, Steam Guard bölümünden QR kodu okut ve girişi onayla.';

  const st = {
    tab: 'idle', games: [], gamesLoaded: false, sel: new Set(), chip: 'all',
    idle: null, hasSaved: false, canRemember: true, loginMode: 'pw',
    prefs: {
      selected: [], rotateMin: 30, muted: false, groupMode: true, lists: [], lastIdle: null,
      autoStart: false, startHidden: false, autoIdle: false, closeToTray: false, minToTray: false,
      persona: 'online', notify: true
    },
    aSel: new Set(), aBusy: false, aRes: new Map(), ad: null,
    menuItems: [], dlgResolve: null,
    guardT: 0, tick: 0, saveT: 0, qT: 0, aqT: 0, toastT: 0
  };

  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const lower = (s) => String(s).toLocaleLowerCase('tr');
  const fmt = (ms) => {
    const s = Math.max(0, Math.floor(ms / 1000));
    return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((n) => String(n).padStart(2, '0')).join(':');
  };

  // ---- ses (WebAudio, dosya yok) --------------------------------------------
  let ac = null;
  function play(notes) {
    if (st.prefs.muted) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      if (ac.state === 'suspended') ac.resume();
      const t0 = ac.currentTime;
      for (const [f, at, dur] of notes) {
        const o = ac.createOscillator();
        const g = ac.createGain();
        o.type = 'sine';
        o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t0 + at);
        g.gain.exponentialRampToValueAtTime(0.06, t0 + at + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
        o.connect(g);
        g.connect(ac.destination);
        o.start(t0 + at);
        o.stop(t0 + at + dur + 0.05);
      }
    } catch (e) { /* ses yoksa sessiz devam */ }
  }
  const sfx = {
    pick: () => play([[740, 0, 0.09]]),
    on: () => play([[523, 0, 0.12], [784, 0.1, 0.18]]),
    off: () => play([[784, 0, 0.12], [523, 0.1, 0.18]]),
    done: () => play([[659, 0, 0.12], [831, 0.12, 0.12], [988, 0.24, 0.22]]),
    err: () => play([[330, 0, 0.2]])
  };

  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(st.toastT);
    st.toastT = setTimeout(() => t.classList.remove('show'), 4200);
  }

  // ---- süsler ------------------------------------------------------------------
  (() => {
    const d = $('#dust');
    for (let i = 0; i < 16; i++) {
      const s = document.createElement('i');
      s.style.setProperty('--x', Math.random() * 100 + '%');
      s.style.setProperty('--s', 2 + Math.random() * 3 + 'px');
      s.style.setProperty('--d', 16 + Math.random() * 18 + 's');
      s.style.setProperty('--delay', -Math.random() * 30 + 's');
      d.appendChild(s);
    }
  })();

  const screen = (name) => {
    $('#login').classList.toggle('hidden', name !== 'login');
    $('#app').classList.toggle('hidden', name !== 'app');
  };

  // ---- giriş -------------------------------------------------------------------
  function loginBusy(b) {
    $('#btn-login').disabled = b;
    $('#btn-resume').disabled = b;
    $('#btn-login').textContent = b ? 'Bağlanılıyor…' : 'Giriş yap';
  }
  function loginErr(msg) {
    const e = $('#login-err');
    e.textContent = msg || '';
    e.classList.toggle('hidden', !msg);
  }
  function syncSaved() {
    $('#saved').classList.toggle('hidden', !(st.hasSaved && st.savedName && st.loginMode === 'pw'));
  }

  function setQr(q) {
    const over = $('#qr-over');
    const show = (text) => { over.textContent = text; over.classList.remove('hidden'); };
    if (q.status === 'loading') show('QR kodu hazırlanıyor…');
    else if (q.status === 'waiting') {
      $('#qr-img').src = q.image;
      over.classList.add('hidden');
      $('#qr-text').textContent = QR_HELP;
    }
    else if (q.status === 'scanned') show('Okundu. Şimdi telefondan girişi onayla.');
    else if (q.status === 'expired') show('QR kodun süresi doldu. Aşağıdan yenile.');
    else if (q.status === 'error') show(q.message || 'QR kodu oluşturulamadı.');
    else if (q.status === 'signing') show('Giriş yapılıyor…');
  }
  function startQr() {
    setQr({ status: 'loading' });
    api.qrStart({ remember: $('#remember').checked });
  }
  function setLoginMode(mode) {
    const qr = mode === 'qr';
    const changed = st.loginMode !== mode;
    st.loginMode = mode;
    $('#seg-pw').classList.toggle('on', !qr);
    $('#seg-qr').classList.toggle('on', qr);
    $('#seg-pw').setAttribute('aria-selected', String(!qr));
    $('#seg-qr').setAttribute('aria-selected', String(qr));
    $('#pw-fields').classList.toggle('hidden', qr);
    $('#qr-pane').classList.toggle('hidden', !qr);
    $('#btn-login').classList.toggle('hidden', qr);
    $('#acc').required = !qr;
    $('#pass').required = !qr;
    syncSaved();
    if (qr) startQr();
    else if (changed) api.qrCancel();
  }
  $('#seg-pw').addEventListener('click', () => setLoginMode('pw'));
  $('#seg-qr').addEventListener('click', () => setLoginMode('qr'));
  $('#qr-refresh').addEventListener('click', startQr);
  $('#remember').addEventListener('change', () => { if (st.loginMode === 'qr') startQr(); });
  api.onQr(setQr);

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (st.loginMode === 'qr') return;
    loginErr('');
    loginBusy(true);
    const r = await api.login({ accountName: $('#acc').value, password: $('#pass').value, remember: $('#remember').checked });
    $('#pass').value = '';
    if (!r.ok) { loginBusy(false); loginErr(r.message); }
  });
  $('#btn-resume').addEventListener('click', async () => {
    loginErr('');
    loginBusy(true);
    const r = await api.resume();
    if (!r.ok) { loginBusy(false); loginErr(r.message); }
  });
  $('#btn-forget').addEventListener('click', async () => {
    await api.forget();
    st.hasSaved = false;
    syncSaved();
    renderSettings();
  });

  // ---- Steam Guard --------------------------------------------------------------
  function countdown(ms) {
    clearInterval(st.guardT);
    const btn = $('#btn-code');
    const end = Date.now() + ms;
    const tick = () => {
      const left = Math.ceil((end - Date.now()) / 1000);
      if (left > 0) {
        btn.disabled = true;
        btn.textContent = `Yeni kod için ${left} sn bekle`;
      } else {
        btn.disabled = false;
        btn.textContent = 'Kodu gönder';
        clearInterval(st.guardT);
      }
    };
    tick();
    if (ms > 0) st.guardT = setInterval(tick, 250);
  }
  function openGuard(g) {
    $('#guard').classList.remove('hidden');
    $('#guard-title').textContent = g.email ? 'E-posta kodunu gir' : 'Steam Guard kodunu gir';
    $('#guard-sub').textContent = g.email ? `Kod ${g.email} adresine gönderildi.` : 'Telefondaki Steam uygulamasında görünen kodu yaz.';
    const err = $('#guard-err');
    err.textContent = g.wrong ? 'Kod yanlış. Steam seni kilitlemesin diye yeni bir kod için biraz bekle.' : '';
    err.classList.toggle('hidden', !g.wrong);
    $('#code').value = '';
    countdown(g.waitMs || 0);
    setTimeout(() => $('#code').focus(), 50);
  }
  function closeGuard() {
    clearInterval(st.guardT);
    $('#guard').classList.add('hidden');
  }
  $('#guard-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const r = await api.guard($('#code').value);
    if (!r.ok) {
      const err = $('#guard-err');
      err.textContent = r.message || 'Kod gönderilemedi.';
      err.classList.remove('hidden');
      if (r.waitMs) countdown(r.waitMs);
    }
  });
  $('#btn-guard-cancel').addEventListener('click', () => api.logout());

  // ---- Steam durumu --------------------------------------------------------------
  function setLoading(l, t) {
    $('#loading-text').textContent = t ? `Kütüphane okunuyor… ${l} / ${t}` : 'Kütüphane okunuyor…';
    $('#bar').style.width = (t ? Math.round((l / t) * 100) : 6) + '%';
  }
  function showTab(name) {
    st.tab = name;
    $$('.nav button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    $('#tab-idle').classList.toggle('hidden', name !== 'idle' || !st.gamesLoaded);
    $('#tab-ach').classList.toggle('hidden', name !== 'ach' || !st.gamesLoaded);
    $('#tab-set').classList.toggle('hidden', name !== 'set');
    $('#loading').classList.toggle('hidden', st.gamesLoaded || name === 'set');
  }
  function enterApp(account) {
    screen('app');
    $('#acct-name').textContent = account || '';
    showTab(st.tab);
  }
  function leaveApp() {
    closeGuard();
    closeMenu();
    loginBusy(false);
    screen('login');
    st.games = []; st.gamesLoaded = false; st.sel = new Set(); st.aSel = new Set(); st.aRes.clear(); st.aBusy = false; st.idle = null;
    clearInterval(st.tick);
    $('#grid').innerHTML = '';
    $('#alist').innerHTML = '';
    renderOrb();
    setLoginMode('pw');
  }

  api.onState((s) => {
    if (s.status === 'connecting') {
      loginBusy(true);
      closeGuard();
      if (st.loginMode === 'qr') setQr({ status: 'signing' });
    } else if (s.status === 'guard') {
      loginBusy(true);
      openGuard(s.guard || {});
    } else if (s.status === 'loading') {
      closeGuard();
      if ($('#remember').checked && st.canRemember) { st.hasSaved = true; st.savedName = s.account; }
      enterApp(s.account);
      setLoading(0, 0);
    } else if (s.status === 'out') {
      leaveApp();
    }
  });
  api.onFail((f) => {
    loginErr(f.message);
    sfx.err();
    if (f.tokenBad) { st.hasSaved = false; syncSaved(); renderSettings(); }
  });
  api.onProgress((p) => setLoading(p.loaded, p.total));

  function applyGames(games, account) {
    if (account) enterApp(account);
    st.games = games;
    st.gamesLoaded = true;
    const owned = new Set(games.map((g) => g.appid));
    st.sel = new Set((st.prefs.selected || []).filter((id) => owned.has(id)));
    showTab(st.tab);
    renderGrid();
    renderAch();
    renderDock();
    renderLists();
    renderSettings();
  }
  api.onGames((games) => applyGames(games));

  // ---- sekmeler ---------------------------------------------------------------------
  $$('.nav button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));

  // ---- oyun listesi --------------------------------------------------------------------
  const imgUrl = (id, t) => [
    `https://cdn.cloudflare.steamstatic.com/steam/apps/${id}/header.jpg`,
    `https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/${id}/header.jpg`
  ][t] || null;

  function visible() {
    const q = lower($('#q').value).trim();
    return st.games.filter((g) => {
      if (st.chip === 'cards' && !g.cards) return false;
      if (st.chip === 'sel' && !st.sel.has(g.appid)) return false;
      return !q || lower(g.name).includes(q);
    });
  }
  function cardHtml(g) {
    const on = st.sel.has(g.appid);
    return `<button class="card${on ? ' on' : ''}" data-id="${g.appid}" aria-pressed="${on}">` +
      `<span class="art"><img loading="lazy" alt="" data-t="0" data-id="${g.appid}" src="${imgUrl(g.appid, 0)}"></span>` +
      '<span class="tick" aria-hidden="true">✓</span>' +
      `<span class="name">${esc(g.name)}</span>` +
      `<span class="tags">${g.cards ? '<i title="Kartı var">🃏</i>' : ''}${g.ach ? '<i title="Başarımı var">🏆</i>' : ''}</span>` +
      '</button>';
  }
  function renderGrid() {
    const list = visible();
    $('#grid').innerHTML = list.map(cardHtml).join('');
    $('#grid').classList.toggle('hidden', !list.length);
    const empty = $('#empty');
    empty.classList.toggle('hidden', list.length > 0);
    empty.textContent = st.games.length
      ? 'Aramana uyan oyun yok. Farklı bir kelime dene.'
      : 'Kütüphanende oyun bulunamadı. Aile paylaşımıyla gelen oyunlar listelenmez.';
  }
  function saveSel() {
    clearTimeout(st.saveT);
    st.saveT = setTimeout(() => api.setPrefs({ selected: Array.from(st.sel) }), 400);
  }
  function selChanged() {
    saveSel();
    renderDock();
    renderLists();
  }
  function toggle(id, el) {
    if (st.sel.has(id)) st.sel.delete(id); else st.sel.add(id);
    const on = st.sel.has(id);
    if (el) { el.classList.toggle('on', on); el.setAttribute('aria-pressed', String(on)); }
    sfx.pick();
    selChanged();
  }

  $('#grid').addEventListener('click', (e) => {
    const b = e.target.closest('.card');
    if (b) toggle(Number(b.dataset.id), b);
  });
  $('#grid').addEventListener('error', (e) => {
    const img = e.target;
    if (!img || img.tagName !== 'IMG') return;
    const t = Number(img.dataset.t) + 1;
    const url = imgUrl(img.dataset.id, t);
    if (url) { img.dataset.t = String(t); img.src = url; } else { img.classList.add('broken'); }
  }, true);

  $('#q').addEventListener('input', () => { clearTimeout(st.qT); st.qT = setTimeout(renderGrid, 120); });
  $$('.chip').forEach((c) => c.addEventListener('click', () => {
    st.chip = c.dataset.chip;
    $$('.chip').forEach((x) => x.classList.toggle('on', x === c));
    renderGrid();
  }));
  $('#btn-sel-vis').addEventListener('click', () => { visible().forEach((g) => st.sel.add(g.appid)); sfx.pick(); renderGrid(); selChanged(); });
  $('#btn-sel-cards').addEventListener('click', () => { st.games.filter((g) => g.cards).forEach((g) => st.sel.add(g.appid)); sfx.pick(); renderGrid(); selChanged(); });
  $('#btn-clear').addEventListener('click', () => { st.sel.clear(); renderGrid(); selChanged(); });

  // ---- idle: halka, durum çubuğu ------------------------------------------------------------
  function renderOrb() {
    const i = st.idle;
    let state = 'off', kind = 'word', t = 'Kapalı', s = 'Idle bekliyor';
    if (i && i.on) {
      if (i.paused) { state = 'warn'; t = 'Duraklatıldı'; s = 'Başarım işlemi sürüyor'; }
      else if (!i.online) { state = 'warn'; t = 'Bağlantı yok'; s = 'Yeniden bağlanılıyor'; }
      else if (i.blockedBy) { state = 'warn'; t = 'Engellendi'; s = 'Başka yerde oyun var'; }
      else { state = 'on'; kind = 'time'; t = fmt(Date.now() - i.startedAt); s = `${i.playing} oyun idle`; }
    }
    const o = $('#orb');
    o.dataset.state = state;
    o.dataset.kind = kind;
    $('#orb-t').textContent = t;
    $('#orb-s').textContent = s;
  }
  function renderStatus() {
    const i = st.idle;
    const el = $('#status');
    const n = st.sel.size;
    if (i && i.on) {
      const time = fmt(Date.now() - i.startedAt);
      if (i.paused) el.textContent = 'Başarım işlemi bitene kadar idle duraklatıldı.';
      else if (!i.online) el.textContent = 'Bağlantı koptu, Steam’e yeniden bağlanılıyor…';
      else if (i.blockedBy) el.textContent = 'Bu hesapla başka bir yerde oyun oynanıyor. O oyun kapanınca idle kendiliğinden devam eder.';
      else if (!i.grouped && i.total > MAX) el.textContent = `${i.total} oyun tek seferde gönderildi, ${time}. Steam en fazla 32 oyunu sayar, fazlası sayılmayabilir.`;
      else if (i.batches > 1) el.textContent = `${i.playing} oyun idle ediliyor, ${time}. Grup ${i.batch}/${i.batches}, ${i.rotateMin} dk’da bir değişir.`;
      else el.textContent = `${i.playing} oyun idle ediliyor, ${time}`;
    } else if (n > MAX && st.prefs.groupMode) {
      el.textContent = 'Steam aynı anda en fazla 32 oyunu sayar. Fazlası gruplar hâlinde sırayla döner.';
    } else if (n > MAX) {
      el.textContent = `Grup modu kapalı: ${n} oyun tek seferde gönderilecek. Steam 32’den fazlasını saymayabilir.`;
    } else {
      el.textContent = '';
    }
  }
  function renderDock() {
    const on = !!(st.idle && st.idle.on);
    const n = st.sel.size;
    const b = $('#btn-start');
    b.disabled = n === 0;
    if (on) b.textContent = n ? `Seçimi güncelle (${n})` : 'Seçimi güncelle';
    else b.textContent = n ? `Seçilenleri başlat (${n})` : 'Oyun seç';
    $('#btn-stop').classList.toggle('hidden', !on);
    $('#btn-newlist').disabled = n === 0;
    $('#sw-group').checked = !!st.prefs.groupMode;
    $('#rot').classList.toggle('hidden', !(st.prefs.groupMode && n > MAX));
    $('#count').textContent = `${st.games.length} oyun, ${n} seçili`;
    renderStatus();
  }

  const rotMin = () => Number($('#rot-min').value) || st.prefs.rotateMin || 30;
  $('#btn-start').addEventListener('click', async () => {
    if (!st.sel.size) return;
    const r = await api.idleStart(Array.from(st.sel), rotMin(), st.prefs.groupMode);
    if (!r.ok) { toast(r.message || 'Idle başlatılamadı.'); sfx.err(); return; }
    sfx.on();
  });
  $('#btn-stop').addEventListener('click', async () => { await api.idleStop(); sfx.off(); });
  $('#rot-min').addEventListener('change', (e) => {
    st.prefs.rotateMin = Number(e.target.value) || 30;
    api.setPrefs({ rotateMin: st.prefs.rotateMin });
  });
  $('#sw-group').addEventListener('change', (e) => {
    st.prefs.groupMode = e.target.checked;
    api.idleMode(e.target.checked);
    sfx.pick();
    renderDock();
  });

  api.onIdle((i) => {
    st.idle = i;
    clearInterval(st.tick);
    if (i.on) st.tick = setInterval(() => { renderStatus(); renderOrb(); }, 1000);
    renderOrb();
    renderDock();
  });

  // ---- pencere ve menü yardımcıları -----------------------------------------------------------------
  function askText(o) {
    return new Promise((resolve) => {
      $('#dlg-title').textContent = o.title;
      $('#dlg-label').textContent = o.label || 'Liste adı';
      const input = $('#dlg-input');
      input.value = o.value || '';
      $('#dlg-check-row').classList.toggle('hidden', !o.check);
      if (o.check) {
        $('#dlg-check').checked = !!o.check.checked;
        $('#dlg-check').disabled = !!o.check.disabled;
        $('#dlg-check-text').textContent = o.check.text;
      }
      $('#dlg-ok').textContent = o.ok || 'Tamam';
      $('#dlg').classList.remove('hidden');
      st.dlgResolve = resolve;
      setTimeout(() => { input.focus(); input.select(); }, 30);
    });
  }
  function closeDlg(result) {
    $('#dlg').classList.add('hidden');
    const r = st.dlgResolve;
    st.dlgResolve = null;
    if (r) r(result);
  }
  $('#dlg-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('#dlg-input').value.trim();
    if (v) closeDlg({ value: v, checked: $('#dlg-check').checked });
  });
  $('#dlg-cancel').addEventListener('click', () => closeDlg(null));

  function closeMenu() {
    $('#menu').classList.add('hidden');
    st.menuItems = [];
  }
  function openMenu(items, anchor) {
    const m = $('#menu');
    st.menuItems = items;
    m.innerHTML = items.map((it, i) => `<button role="menuitem" data-i="${i}"${it.danger ? ' class="danger"' : ''}>${esc(it.label)}</button>`).join('');
    m.classList.remove('hidden');
    const r = anchor.getBoundingClientRect();
    const w = m.offsetWidth;
    const h = m.offsetHeight;
    m.style.left = Math.max(8, Math.min(r.right - w, window.innerWidth - w - 8)) + 'px';
    m.style.top = Math.max(8, Math.min(r.bottom + 4, window.innerHeight - h - 8)) + 'px';
  }
  $('#menu').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const it = st.menuItems[Number(b.dataset.i)];
    closeMenu();
    if (it) it.run();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#menu') && !e.target.closest('.list-more')) closeMenu(); });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (!$('#dlg').classList.contains('hidden')) closeDlg(null);
    if (!$('#ach-detail').classList.contains('hidden')) closeAchDetail();
    closeMenu();
  });

  // ---- listelerim ------------------------------------------------------------------------------------
  const ownedSet = () => new Set(st.games.map((g) => g.appid));
  const listOwned = (l) => { const o = ownedSet(); return l.ids.filter((id) => o.has(id)); };
  const sameSet = (set, arr) => set.size === arr.length && arr.every((x) => set.has(x));
  const newId = () => 'l' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const saveLists = () => api.setPrefs({ lists: st.prefs.lists });

  function renderLists() {
    const el = $('#lists');
    const lists = st.prefs.lists || [];
    if (!lists.length) {
      el.innerHTML = '<p class="lists-empty">Henüz liste yok. Oyunları seçip + düğmesiyle liste yapabilirsin.</p>';
      return;
    }
    el.innerHTML = lists.map((l) => {
      const owned = listOwned(l);
      const active = owned.length > 0 && sameSet(st.sel, owned);
      return `<div class="list${active ? ' on' : ''}" data-id="${esc(l.id)}">` +
        `<button class="list-main" title="Listedeki oyunları seç"><span class="list-name">${esc(l.name)}</span><span class="list-count">${owned.length}</span></button>` +
        `<button class="list-play" title="Bu listeyi başlat" aria-label="${esc(l.name)} listesini başlat"><svg aria-hidden="true"><use href="#i-play"/></svg></button>` +
        `<button class="list-more" title="Diğer işlemler" aria-label="${esc(l.name)} liste menüsü"><svg aria-hidden="true"><use href="#i-more"/></svg></button>` +
        '</div>';
    }).join('');
  }
  const findList = (id) => (st.prefs.lists || []).find((x) => x.id === id);

  function loadList(id) {
    const l = findList(id);
    if (!l) return;
    const owned = listOwned(l);
    if (!owned.length) { toast('Bu listede bu hesapta bulunan oyun yok.'); return; }
    st.sel = new Set(owned);
    st.chip = 'sel';
    $$('.chip').forEach((x) => x.classList.toggle('on', x.dataset.chip === 'sel'));
    $('#q').value = '';
    showTab('idle');
    sfx.pick();
    renderGrid();
    selChanged();
  }
  async function startList(id) {
    const l = findList(id);
    if (!l) return;
    const owned = listOwned(l);
    if (!owned.length) { toast('Bu listede bu hesapta bulunan oyun yok.'); sfx.err(); return; }
    st.sel = new Set(owned);
    renderGrid();
    selChanged();
    const r = await api.idleStart(owned, rotMin(), st.prefs.groupMode);
    if (!r.ok) { toast(r.message || 'Idle başlatılamadı.'); sfx.err(); return; }
    sfx.on();
    toast(`“${l.name}” listesi başlatıldı.`);
  }
  async function createList() {
    if ((st.prefs.lists || []).length >= 60) { toast('En fazla 60 liste yapabilirsin.'); return; }
    const n = st.sel.size;
    const r = await askText({
      title: 'Yeni liste', label: 'Liste adı', ok: 'Oluştur',
      check: { text: n ? `Seçili ${n} oyunu ekle` : 'Önce oyun seçersen buraya ekleyebilirsin', checked: n > 0, disabled: n === 0 }
    });
    if (!r) return;
    const l = { id: newId(), name: r.value.slice(0, 40), ids: r.checked ? Array.from(st.sel) : [] };
    st.prefs.lists = (st.prefs.lists || []).concat(l);
    saveLists();
    renderLists();
    sfx.on();
    toast(`“${l.name}” listesi oluşturuldu.`);
  }
  async function renameList(id) {
    const l = findList(id);
    if (!l) return;
    const r = await askText({ title: 'Listeyi yeniden adlandır', label: 'Liste adı', value: l.name, ok: 'Kaydet' });
    if (!r) return;
    l.name = r.value.slice(0, 40);
    saveLists();
    renderLists();
  }
  function saveSelToList(id) {
    const l = findList(id);
    if (!l) return;
    if (!st.sel.size) { toast('Önce Oyunlar sekmesinden oyun seç.'); return; }
    l.ids = Array.from(st.sel);
    saveLists();
    renderLists();
    sfx.on();
    toast(`Seçim “${l.name}” listesine kaydedildi.`);
  }
  function deleteList(id) {
    const l = findList(id);
    if (!l) return;
    if (!window.confirm(`“${l.name}” listesi silinsin mi?`)) return;
    st.prefs.lists = st.prefs.lists.filter((x) => x.id !== id);
    saveLists();
    renderLists();
  }

  $('#lists').addEventListener('click', (e) => {
    const row = e.target.closest('.list');
    if (!row) return;
    const id = row.dataset.id;
    if (e.target.closest('.list-play')) startList(id);
    else if (e.target.closest('.list-more')) {
      openMenu([
        { label: 'Yeniden adlandır', run: () => renameList(id) },
        { label: 'Seçimi bu listeye kaydet', run: () => saveSelToList(id) },
        { label: 'Listeyi sil', danger: true, run: () => deleteList(id) }
      ], e.target.closest('.list-more'));
    } else if (e.target.closest('.list-main')) loadList(id);
  });
  $('#btn-list-new').addEventListener('click', createList);
  $('#btn-newlist').addEventListener('click', createList);

  // ---- başarımlar ------------------------------------------------------------------------------------
  function achList() {
    const q = lower($('#aq').value).trim();
    return st.games.filter((g) => g.ach && !g.vac && (!q || lower(g.name).includes(q)));
  }
  function rowHtml(g) {
    const on = st.aSel.has(g.appid);
    return `<div class="arow${on ? ' on' : ''}" data-id="${g.appid}">` +
      `<input type="checkbox"${on ? ' checked' : ''}${st.aBusy ? ' disabled' : ''} aria-label="${esc(g.name)}">` +
      `<span class="aname">${esc(g.name)}</span>` +
      `<span class="ares" data-res="${g.appid}">${esc(st.aRes.get(g.appid) || '')}</span>` +
      `<button type="button" class="icon-btn arow-pick" data-pick="${g.appid}" title="Tek tek seç" aria-label="${esc(g.name)} başarımlarını tek tek seç"${st.aBusy ? ' disabled' : ''}><svg aria-hidden="true"><use href="#i-list"/></svg></button>` +
      '</div>';
  }
  function renderAch() {
    const list = achList();
    $('#alist').innerHTML = list.length ? list.map(rowHtml).join('') : '<p class="empty">Başarımı olan bir oyun bulunamadı.</p>';
    renderAchDock();
  }
  function renderAchDock() {
    const n = st.aSel.size;
    const run = $('#a-run');
    run.classList.toggle('hidden', st.aBusy);
    run.disabled = n === 0;
    run.textContent = n ? `Başarımları aç (${n} oyun)` : 'Oyun seç';
    $('#a-cancel').classList.toggle('hidden', !st.aBusy);
  }
  function resultText(e) {
    if (!e.ok) return e.message || 'Açılamadı.';
    if (!e.unlocked && !e.failed) return `Hepsi zaten açık (${e.already})`;
    if (!e.failed) return `${e.unlocked} başarım açıldı`;
    return `${e.unlocked} açıldı, ${e.failed} açılamadı`;
  }

  // Steam Web API bir başarımın gerçek görünen adını vermiyor (buna kişisel bir
  // API anahtarı gerekir); elimizdeki tek şey teknik "API adı". Onu biraz daha
  // okunur hâle getiriyoruz, birebir oyun içi metin olduğunu iddia etmeden.
  function prettyAch(name) {
    const s = name.replace(/^ACH(IEVEMENT)?[_.\-]?/i, '').replace(/[_\-.]+/g, ' ').trim();
    const base = s || name;
    return base.replace(/\S+/g, (w) => (/[a-zA-Z]/.test(w) ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w));
  }

  function renderAdList() {
    const ad = st.ad;
    if (!ad) return;
    $('#ad-list').innerHTML = ad.items.length
      ? ad.items.map((it) => {
        const on = ad.sel.has(it.name);
        return `<label class="ad-row${on ? ' on' : ''}${it.unlocked ? ' done' : ''}">` +
          `<input type="checkbox"${on ? ' checked' : ''}${ad.busy ? ' disabled' : ''} data-name="${esc(it.name)}">` +
          `<span class="ad-name">${esc(prettyAch(it.name))}</span>` +
          `<span class="ad-meta">${it.unlocked ? 'Zaten açık' : it.percent.toFixed(1) + '%'}</span></label>`;
      }).join('')
      : '<p class="empty">Başarım bulunamadı.</p>';
    renderAdDock();
  }
  function renderAdDock() {
    const ad = st.ad;
    if (!ad) return;
    const n = ad.sel.size;
    $('#ad-sel-all').disabled = ad.busy;
    $('#ad-clear').disabled = ad.busy;
    $('#ad-run').classList.toggle('hidden', ad.busy);
    $('#ad-cancel').classList.toggle('hidden', !ad.busy);
    $('#ad-run').disabled = n === 0;
    $('#ad-run').textContent = n ? `Seçilenleri aç (${n})` : 'Başarım seç';
  }
  async function openAchDetail(appId) {
    const g = st.games.find((x) => x.appid === appId);
    if (!g) return;
    st.ad = { appId, sel: new Set(), items: [], busy: false };
    $('#ad-title').textContent = g.name;
    $('#ad-sub').textContent = 'Başarımlar okunuyor…';
    $('#ad-status').textContent = '';
    $('#ad-list').innerHTML = '';
    $('#ad-run').disabled = true;
    $('#ad-run').textContent = 'Başarım seç';
    $('#ach-detail').classList.remove('hidden');
    const r = await api.achList(appId);
    if (!st.ad || st.ad.appId !== appId) return; // bu sırada kapatıldı ya da başka oyun açıldı
    if (!r.ok) { $('#ad-sub').textContent = r.message || 'Başarımlar okunamadı.'; return; }
    st.ad.items = r.items;
    $('#ad-sub').textContent = (r.partial ? (r.message || 'Açık/kapalı durumları okunamadı.') + ' ' : '') +
      'Gerçek başarım adları herkese açık olmadığından teknik adların sadeleştirilmiş hâli gösteriliyor.';
    renderAdList();
  }
  function closeAchDetail() {
    $('#ach-detail').classList.add('hidden');
    st.ad = null;
  }
  $('#ad-list').addEventListener('change', (e) => {
    const cb = e.target.closest('input[type=checkbox]');
    if (!cb || !st.ad) return;
    const name = cb.dataset.name;
    if (cb.checked) st.ad.sel.add(name); else st.ad.sel.delete(name);
    cb.closest('.ad-row').classList.toggle('on', cb.checked);
    sfx.pick();
    renderAdDock();
  });
  $('#ad-sel-all').addEventListener('click', () => { if (!st.ad) return; st.ad.items.forEach((it) => st.ad.sel.add(it.name)); sfx.pick(); renderAdList(); });
  $('#ad-clear').addEventListener('click', () => { if (!st.ad) return; st.ad.sel.clear(); renderAdList(); });
  $('#ad-close').addEventListener('click', closeAchDetail);
  $('#ad-cancel').addEventListener('click', () => api.achCancel());
  $('#ad-run').addEventListener('click', async () => {
    const ad = st.ad;
    if (!ad || !ad.sel.size || ad.busy) return;
    ad.busy = true;
    $('#ad-status').textContent = 'Başlıyor…';
    renderAdList();
    const r = await api.achRunSome(ad.appId, Array.from(ad.sel));
    if (!r.ok) {
      ad.busy = false;
      $('#ad-status').textContent = '';
      toast(r.message || 'Başlatılamadı.');
      renderAdList();
    }
  });

  $('#alist').addEventListener('change', (e) => {
    const row = e.target.closest('.arow');
    if (!row) return;
    const id = Number(row.dataset.id);
    if (e.target.checked) st.aSel.add(id); else st.aSel.delete(id);
    row.classList.toggle('on', e.target.checked);
    sfx.pick();
    renderAchDock();
  });
  $('#alist').addEventListener('click', (e) => {
    const pick = e.target.closest('.arow-pick');
    if (pick) { openAchDetail(Number(pick.dataset.pick)); return; }
    if (e.target.matches('input[type=checkbox]') || st.aBusy) return;
    const row = e.target.closest('.arow');
    const cb = row && row.querySelector('input[type=checkbox]');
    if (!cb || cb.disabled) return;
    cb.checked = !cb.checked;
    cb.dispatchEvent(new Event('change', { bubbles: true }));
  });
  $('#aq').addEventListener('input', () => { clearTimeout(st.aqT); st.aqT = setTimeout(renderAch, 120); });
  $('#a-sel').addEventListener('click', () => { achList().forEach((g) => st.aSel.add(g.appid)); sfx.pick(); renderAch(); });
  $('#a-clear').addEventListener('click', () => { st.aSel.clear(); renderAch(); });
  $('#a-run').addEventListener('click', async () => {
    const ids = Array.from(st.aSel);
    if (!ids.length || st.aBusy) return;
    if (!window.confirm(`${ids.length} oyunun bütün başarımları açılacak. Devam edilsin mi?`)) return;
    st.aBusy = true;
    st.aRes.clear();
    $('#a-status').textContent = 'Başlıyor…';
    renderAch();
    const r = await api.achRun(ids);
    if (!r.ok) { st.aBusy = false; $('#a-status').textContent = ''; toast(r.message || 'Başarım işlemi başlatılamadı.'); renderAch(); }
  });
  $('#a-cancel').addEventListener('click', () => api.achCancel());

  api.onAch((e) => {
    if (st.ad && st.ad.appId === e.appId) {
      if (e.type === 'start') $('#ad-status').textContent = 'Açılıyor…';
      else if (e.type === 'progress') $('#ad-status').textContent = `${e.done} / ${e.total}`;
      else if (e.type === 'done') {
        st.ad.busy = false;
        $('#ad-status').textContent = resultText(e);
        if (e.ok) {
          const done = new Set(st.ad.sel);
          st.ad.items = st.ad.items.map((it) => (done.has(it.name) ? Object.assign({}, it, { unlocked: true }) : it));
        }
        renderAdList();
      }
    }
    if (e.type === 'finished') {
      st.aBusy = false;
      $('#a-status').textContent = e.cancelled ? 'İptal edildi.' : 'Bitti.';
      renderAch();
      if (!e.cancelled) sfx.done();
      return;
    }
    const set = (t) => {
      st.aRes.set(e.appId, t);
      const el = document.querySelector(`[data-res="${e.appId}"]`);
      if (el) el.textContent = t;
    };
    if (e.type === 'start') { set('Açılıyor…'); $('#a-status').textContent = `${e.index + 1} / ${e.total} oyun`; }
    else if (e.type === 'progress') set(`${e.done} / ${e.total}`);
    else if (e.type === 'done') set(resultText(e));
  });

  // ---- ayarlar ------------------------------------------------------------------------------------------
  const syncMute = () => { $('#btn-mute').textContent = st.prefs.muted ? '🔇' : '🔊'; };
  function renderSettings() {
    $$('[data-pref]').forEach((i) => { i.checked = !!st.prefs[i.dataset.pref]; });
    $('#sw-sound').checked = !st.prefs.muted;
    $$('#persona-seg button').forEach((b) => b.classList.toggle('on', b.dataset.persona === st.prefs.persona));
    const hint = $('#hint-auto');
    const need = st.prefs.autoIdle && !st.hasSaved;
    hint.classList.toggle('warn', need);
    hint.textContent = need
      ? 'Bunun çalışması için “Oturumu hatırla” ile giriş yapmış olman gerekir.'
      : 'Kayıtlı oturumla giriş yapar ve en son başlattığın seçimi idle etmeye devam eder.';
    syncMute();
  }
  $$('[data-pref]').forEach((i) => i.addEventListener('change', () => {
    st.prefs[i.dataset.pref] = i.checked;
    api.setPrefs({ [i.dataset.pref]: i.checked });
    sfx.pick();
    renderSettings();
  }));
  $('#sw-sound').addEventListener('change', (e) => {
    st.prefs.muted = !e.target.checked;
    api.setPrefs({ muted: st.prefs.muted });
    renderSettings();
  });
  $$('#persona-seg button').forEach((b) => b.addEventListener('click', () => {
    st.prefs.persona = b.dataset.persona;
    api.setPrefs({ persona: b.dataset.persona });
    sfx.pick();
    renderSettings();
  }));

  // ---- yan çubuk -----------------------------------------------------------------------------------------------
  $('#btn-mute').addEventListener('click', () => {
    st.prefs.muted = !st.prefs.muted;
    api.setPrefs({ muted: st.prefs.muted });
    renderSettings();
  });
  $('#btn-logout').addEventListener('click', () => api.logout());

  // ---- başlangıç ------------------------------------------------------------------------------------------------
  (async () => {
    const init = await api.init();
    st.prefs = Object.assign(st.prefs, init.prefs);
    st.canRemember = !!init.canRemember;
    $('#rot-min').value = st.prefs.rotateMin || 30;
    if (!init.canRemember) {
      $('#remember').disabled = true;
      $('#remember-hint').textContent = 'Bu bilgisayarda güvenli saklama kullanılamıyor, oturum hatırlanamıyor.';
    }
    if (init.saved) {
      st.hasSaved = true;
      st.savedName = init.saved;
      $('#saved-name').textContent = init.saved;
      $('#acc').value = init.saved;
    }
    syncSaved();
    renderSettings();
    renderLists();
    if (init.idle) st.idle = init.idle;
    const status = init.state && init.state.status;
    if (status === 'ready' && init.games) {
      applyGames(init.games, init.state.account);
      if (st.idle && st.idle.on) st.tick = setInterval(() => { renderStatus(); renderOrb(); }, 1000);
      renderOrb();
      renderDock();
    } else if (status === 'loading' || status === 'connecting' || init.auto) {
      enterApp(init.state.account || init.saved || '');
      setLoading(0, 0);
    }
  })();
})();
