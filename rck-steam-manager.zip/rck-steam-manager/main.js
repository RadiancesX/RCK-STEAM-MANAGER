'use strict';
const { app, BrowserWindow, ipcMain, safeStorage, shell, session, Tray, Menu, Notification, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const QRCode = require('qrcode');
const SteamService = require('./steam-service');

if (!app.requestSingleInstanceLock()) {
  app.quit();
  return;
}

const APP_NAME = 'RCK Steam Manager';
app.setAppUserModelId('com.rck.steammanager');
const ICON_PNG = path.join(__dirname, 'assets', 'icon.png');
const ICON_ICO = path.join(__dirname, 'assets', 'icon.ico');
const AUTOSTART = process.argv.includes('--autostart');

const DEFAULTS = {
  selected: [], rotateMin: 30, muted: false, groupMode: true, lists: [], lastIdle: null,
  autoStart: false, startHidden: false, autoIdle: false, closeToTray: false, minToTray: false,
  persona: 'online', notify: true
};

const steam = new SteamService();
const ach = { running: false, cancel: false, child: null };
let win = null;
let tray = null;
let quitting = false;
let remember = false;
let pendingAuto = null;
let lastBlocked = 0;
let prefs = Object.assign({}, DEFAULTS);

const send = (ch, payload) => {
  if (win && !win.isDestroyed()) win.webContents.send(ch, payload);
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
const ids = (arr) => Array.from(new Set((Array.isArray(arr) ? arr : []).map(Number).filter((n) => Number.isInteger(n) && n > 0)));
const gameName = (id) => {
  const g = steam.games.find((x) => x.appid === id);
  return g ? g.name : 'Oyun ' + id;
};

// ---- küçük dosya deposu (log yok) ----------------------------------------
const file = (name) => path.join(app.getPath('userData'), name);
const readJson = (name, fallback) => {
  try {
    return JSON.parse(fs.readFileSync(file(name), 'utf8'));
  } catch (e) {
    return fallback;
  }
};
const writeJson = (name, value) => {
  try {
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    fs.writeFileSync(file(name), JSON.stringify(value));
  } catch (e) {
    /* yoksay */
  }
};

// Eski "RCK Steam Idle" klasöründeki ayarları ve kayıtlı oturumu yeni klasöre taşı
function migrateOld() {
  try {
    const old = path.join(app.getPath('appData'), 'RCK Steam Idle');
    if (old === app.getPath('userData') || !fs.existsSync(old)) return;
    fs.mkdirSync(app.getPath('userData'), { recursive: true });
    for (const f of ['prefs.json', 'session.json']) {
      if (!fs.existsSync(file(f)) && fs.existsSync(path.join(old, f))) fs.copyFileSync(path.join(old, f), file(f));
    }
  } catch (e) {
    /* yoksay */
  }
}

function cleanLists(arr) {
  return (Array.isArray(arr) ? arr : []).slice(0, 60).map((l) => ({
    id: String((l && l.id) || '').slice(0, 40) || 'l' + Math.random().toString(36).slice(2, 10),
    name: String((l && l.name) || '').trim().slice(0, 40) || 'Liste',
    ids: ids(l && l.ids).slice(0, 5000)
  }));
}

// Renderer'dan gelen ayarları süzer: sadece bilinen anahtarlar ve doğru tipler geçer
function cleanPrefs(p) {
  const out = {};
  if (!p || typeof p !== 'object') return out;
  if (Array.isArray(p.selected)) out.selected = ids(p.selected).slice(0, 5000);
  if (Number.isFinite(Number(p.rotateMin))) out.rotateMin = clamp(Number(p.rotateMin), 5, 240);
  for (const k of ['muted', 'groupMode', 'autoStart', 'startHidden', 'autoIdle', 'closeToTray', 'minToTray', 'notify']) {
    if (typeof p[k] === 'boolean') out[k] = p[k];
  }
  if (['online', 'invisible', 'keep'].includes(p.persona)) out.persona = p.persona;
  if (Array.isArray(p.lists)) out.lists = cleanLists(p.lists);
  if (p.lastIdle === null) out.lastIdle = null;
  else if (p.lastIdle && typeof p.lastIdle === 'object') {
    const l = ids(p.lastIdle.ids).slice(0, 5000);
    out.lastIdle = l.length ? { ids: l, rotateMin: clamp(Number(p.lastIdle.rotateMin) || 30, 5, 240), groupMode: p.lastIdle.groupMode !== false } : null;
  }
  return out;
}

// Şifre hiçbir zaman saklanmaz. "Hatırla" açıksa sadece Windows ile şifrelenmiş giriş anahtarı saklanır.
const canRemember = () => {
  try {
    return safeStorage.isEncryptionAvailable();
  } catch (e) {
    return false;
  }
};
function saveSession(accountName, token) {
  if (!canRemember() || !accountName || !token) return;
  writeJson('session.json', { accountName, token: safeStorage.encryptString(token).toString('base64') });
}
function loadSession() {
  const s = readJson('session.json', null);
  if (!s || !s.accountName || !s.token) return null;
  try {
    return { accountName: s.accountName, token: safeStorage.decryptString(Buffer.from(s.token, 'base64')) };
  } catch (e) {
    return null;
  }
}
function forgetSession() {
  try {
    fs.unlinkSync(file('session.json'));
  } catch (e) {
    /* yoksay */
  }
}

// ---- bildirim --------------------------------------------------------------
function notify(title, body, always) {
  if (!prefs.notify) return;
  if (!always && win && win.isVisible() && win.isFocused()) return;
  try {
    if (Notification.isSupported()) new Notification({ title, body, icon: ICON_PNG }).show();
  } catch (e) {
    /* yoksay */
  }
}

// ---- pencere ve tepsi ---------------------------------------------------------
function showWindow() {
  if (!win) createWindow(true);
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function ensureTray() {
  const need = prefs.closeToTray || prefs.minToTray || prefs.startHidden;
  if (need && !tray) {
    try {
      let img = nativeImage.createFromPath(process.platform === 'win32' ? ICON_ICO : ICON_PNG);
      if (process.platform !== 'win32') img = img.resize({ width: 22, height: 22 });
      tray = new Tray(img);
      tray.on('click', showWindow);
      tray.on('double-click', showWindow);
      refreshTray();
    } catch (e) {
      tray = null;
    }
  } else if (!need && tray) {
    tray.destroy();
    tray = null;
  }
}

function startLast() {
  const l = prefs.lastIdle;
  if (!l || !l.ids.length) return { ok: false };
  return steam.startIdle(l.ids, l.rotateMin, l.groupMode);
}

function refreshTray() {
  if (!tray) return;
  const i = steam.idleInfo();
  const canStart = steam.status === 'ready' && !!(prefs.lastIdle && prefs.lastIdle.ids.length);
  tray.setToolTip(`${APP_NAME}\n${i.on ? i.playing + ' oyun idle ediliyor' : 'Idle kapalı'}`);
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Aç', click: showWindow },
    { type: 'separator' },
    { label: i.on ? `${i.playing} oyun idle ediliyor` : 'Idle kapalı', enabled: false },
    i.on
      ? { label: 'Idle’ı durdur', click: () => steam.stopIdle() }
      : { label: 'Son seçimi başlat', enabled: canStart, click: () => startLast() },
    { type: 'separator' },
    { label: 'Çıkış', click: () => { quitting = true; app.quit(); } }
  ]));
}

function applyAutoStart() {
  try {
    const opts = { openAtLogin: !!prefs.autoStart };
    if (app.isPackaged) {
      opts.path = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
      opts.args = ['--autostart'];
    } else {
      opts.path = process.execPath;
      opts.args = [app.getAppPath(), '--autostart'];
    }
    app.setLoginItemSettings(opts);
  } catch (e) {
    /* yoksay */
  }
}

function applyPrefs(keys) {
  if (keys.includes('autoStart')) applyAutoStart();
  if (['closeToTray', 'minToTray', 'startHidden'].some((k) => keys.includes(k))) ensureTray();
  if (keys.includes('persona')) steam.setPersonaMode(prefs.persona);
}

function createWindow(show) {
  win = new BrowserWindow({
    width: 1180,
    height: 780,
    minWidth: 980,
    minHeight: 660,
    show,
    backgroundColor: '#140f22',
    title: APP_NAME,
    icon: ICON_PNG,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false
    }
  });
  win.removeMenu();
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.on('close', (e) => {
    if (!quitting && prefs.closeToTray && tray) {
      e.preventDefault();
      win.hide();
    }
  });
  win.on('minimize', (e) => {
    if (prefs.minToTray && tray) {
      e.preventDefault();
      win.hide();
    }
  });
  win.on('session-end', () => {
    quitting = true;
  });
  win.on('closed', () => {
    win = null;
  });
}

// ---- Steam olayları -> arayüz ---------------------------------------------
function trackBlocked(i) {
  const b = i.on && !i.paused ? i.blockedBy : 0;
  if (b && !lastBlocked) notify('Idle duraklatıldı', 'Bu hesapla başka bir yerde oyun oynanıyor. O oyun kapanınca idle kendiliğinden devam eder.');
  else if (!b && lastBlocked && i.on) notify('Idle devam ediyor', 'Diğer oyun kapandı, idle yeniden başladı.');
  lastBlocked = b;
}

steam.on('state', (s) => {
  send('steam:state', s);
  refreshTray();
});
steam.on('progress', (p) => send('steam:progress', p));
steam.on('games', (g) => {
  send('steam:games', g);
  if (pendingAuto) {
    const a = pendingAuto;
    pendingAuto = null;
    const r = steam.startIdle(a.ids, a.rotateMin, a.groupMode);
    if (r.ok) notify(APP_NAME, `${r.list.length} oyun idle ediliyor.`);
  }
});
steam.on('idle', (i) => {
  send('steam:idle', i);
  refreshTray();
  trackBlocked(i);
});
steam.on('failure', (f) => {
  if (f.tokenBad) forgetSession();
  send('steam:fail', f);
  if (pendingAuto) {
    // sessiz açılışta giriş yapılamadı: kullanıcının görmesi için pencereyi aç
    pendingAuto = null;
    showWindow();
    notify(APP_NAME, f.message);
  }
});
steam.on('token', (t) => {
  if (remember) saveSession(t.accountName, t.token);
});
steam.on('qr', async (q) => {
  if (q.status === 'waiting' && q.url) {
    try {
      const image = await QRCode.toDataURL(q.url, {
        margin: 1,
        width: 420,
        errorCorrectionLevel: 'M',
        color: { dark: '#140f22', light: '#f4edff' }
      });
      send('steam:qr', { status: 'waiting', image });
    } catch (e) {
      send('steam:qr', { status: 'error', message: 'QR görseli oluşturulamadı.' });
    }
  } else {
    send('steam:qr', q);
  }
});

function maybeAutoIdle() {
  if (!prefs.autoIdle) return;
  const s = loadSession();
  const last = prefs.lastIdle;
  if (!s || !last || !last.ids.length) return;
  pendingAuto = last;
  remember = true;
  steam.loginWithToken(s.accountName, s.token);
}

// ---- başarımlar ------------------------------------------------------------
async function fetchAchievements(appId) {
  const url = `https://api.steampowered.com/ISteamUserStats/GetGlobalAchievementPercentagesForApp/v0002/?gameid=${appId}&format=json`;
  const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error('http ' + res.status);
  const data = await res.json();
  const list = (data && data.achievementpercentages && data.achievementpercentages.achievements) || [];
  return list
    .map((a) => ({ name: String(a.name || ''), percent: Number(a.percent) || 0 }))
    .filter((a) => a.name);
}

const workerPath = () => path.join(__dirname, 'ach-worker.js').replace(`app.asar${path.sep}`, `app.asar.unpacked${path.sep}`);

function runWorker(appId, names, mode) {
  return new Promise((resolve) => {
    let result = null;
    let buf = '';
    let child;
    try {
      child = spawn(process.execPath, [workerPath()], {
        env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }),
        stdio: ['pipe', 'pipe', 'ignore'],
        windowsHide: true
      });
    } catch (e) {
      resolve({ ok: false, error: 'spawn', message: 'Yardımcı işlem başlatılamadı.' });
      return;
    }
    ach.child = child;
    const timer = setTimeout(() => child.kill(), 240000);
    child.stdout.on('data', (d) => {
      buf += d;
      let n;
      while ((n = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, n).trim();
        buf = buf.slice(n + 1);
        if (!line) continue;
        try {
          const m = JSON.parse(line);
          if (m.type === 'result') result = m;
          else send('ach:event', Object.assign({ appId }, m));
        } catch (e) {
          /* yoksay */
        }
      }
    });
    child.on('error', () => {
      clearTimeout(timer);
      resolve({ ok: false, error: 'spawn', message: 'Yardımcı işlem başlatılamadı.' });
    });
    child.on('close', () => {
      clearTimeout(timer);
      resolve(result || { ok: false, error: 'crash', message: 'Yardımcı işlem beklenmedik şekilde kapandı.' });
    });
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify({ appId, names, mode }));
  });
}

// Tek bir oyunun seçilen başarımlarını açar; hem çoklu-oyun akışı hem de tek oyun
// için "tek tek seç" akışı bunu paylaşır.
async function unlockGameAchievements(appId, names) {
  let r = await runWorker(appId, names, 'unlock');
  if (ach.cancel) r = { ok: false, message: 'İptal edildi.' };
  return r;
}

async function runAch(list) {
  ach.running = true;
  ach.cancel = false;
  const wasIdling = steam.idle.on && !steam.idle.paused;
  if (wasIdling) steam.pauseIdle();
  let total = 0;
  try {
    for (let i = 0; i < list.length && !ach.cancel; i++) {
      const appId = list[i];
      send('ach:event', { appId, type: 'start', index: i, total: list.length });
      let meta = [];
      try {
        meta = await fetchAchievements(appId);
      } catch (e) {
        send('ach:event', { appId, type: 'done', ok: false, message: 'Başarım listesi Steam’den alınamadı. İnternetini kontrol et.' });
        continue;
      }
      if (!meta.length) {
        send('ach:event', { appId, type: 'done', ok: false, message: 'Bu oyunda açılabilir başarım bulunamadı.' });
        continue;
      }
      const r = await unlockGameAchievements(appId, meta.map((m) => m.name));
      send('ach:event', Object.assign({ appId }, r, { type: 'done' }));
      if (r.ok && r.unlocked > 0) {
        total += r.unlocked;
        // Steam'in kendi başarım balonu sadece oyunun içinde çıkar; bu yüzden bildirimi biz gösteriyoruz
        if (list.length <= 5) notify(gameName(appId), `${r.unlocked} başarım açıldı`, true);
      }
      if (r.error === 'init') {
        // Steam istemcisi yok: kalan oyunları da denemenin anlamı yok
        for (let j = i + 1; j < list.length; j++) {
          send('ach:event', { appId: list[j], type: 'done', ok: false, message: 'Atlandı, Steam istemcisi bulunamadı.' });
        }
        break;
      }
      await sleep(1000);
    }
  } finally {
    ach.running = false;
    ach.child = null;
    if (wasIdling) steam.resumeIdle();
    if (list.length > 5 && total > 0 && !ach.cancel) notify('Başarımlar açıldı', `${list.length} oyunda toplam ${total} başarım açıldı.`, true);
    send('ach:event', { type: 'finished', cancelled: ach.cancel });
  }
}

// Tek bir oyunun, kullanıcının tek tek işaretlediği başarımlarını açar (bkz. ach:run-some).
async function runAchSome(appId, names) {
  ach.running = true;
  ach.cancel = false;
  const wasIdling = steam.idle.on && !steam.idle.paused;
  if (wasIdling) steam.pauseIdle();
  send('ach:event', { appId, type: 'start', index: 0, total: 1 });
  let r;
  try {
    r = await unlockGameAchievements(appId, names);
  } finally {
    ach.running = false;
    ach.child = null;
    if (wasIdling) steam.resumeIdle();
  }
  send('ach:event', Object.assign({ appId }, r, { type: 'done' }));
  if (r.ok && r.unlocked > 0) notify(gameName(appId), `${r.unlocked} başarım açıldı`, true);
  send('ach:event', { type: 'finished', cancelled: ach.cancel, appId });
}

// ---- IPC ---------------------------------------------------------------------
ipcMain.handle('app:init', () => {
  const s = loadSession();
  return {
    saved: s ? s.accountName : null,
    canRemember: canRemember(),
    prefs,
    state: steam.snapshot(),
    auto: !!pendingAuto,
    games: steam.status === 'ready' ? steam.games : null,
    idle: steam.idleInfo()
  };
});

ipcMain.handle('steam:login', (_e, a) => {
  const accountName = String((a && a.accountName) || '').trim();
  const password = String((a && a.password) || '');
  if (!accountName || !password) return { ok: false, message: 'Hesap adını ve şifreyi yaz.' };
  remember = !!(a && a.remember) && canRemember();
  steam.login(accountName, password);
  return { ok: true };
});

ipcMain.handle('steam:qr-start', (_e, a) => {
  remember = !!(a && a.remember) && canRemember();
  steam.startQr();
  return { ok: true };
});

ipcMain.handle('steam:qr-cancel', () => {
  steam.cancelQr();
  return { ok: true };
});

ipcMain.handle('steam:resume', () => {
  const s = loadSession();
  if (!s) return { ok: false, message: 'Kayıtlı oturum bulunamadı.' };
  remember = true;
  steam.loginWithToken(s.accountName, s.token);
  return { ok: true };
});

ipcMain.handle('steam:forget', () => {
  forgetSession();
  return { ok: true };
});

ipcMain.handle('steam:guard', (_e, code) => steam.submitGuard(String(code || '').replace(/\s/g, '').toUpperCase()));

ipcMain.handle('steam:logout', () => {
  steam.logout();
  return { ok: true };
});

ipcMain.handle('idle:start', (_e, a) => {
  const list = ids(a && a.ids);
  const rotateMin = clamp(Number(a && a.rotateMin) || 30, 5, 240);
  const grouped = !(a && a.groupMode === false);
  const r = steam.startIdle(list, rotateMin, grouped);
  if (r.ok) {
    prefs.lastIdle = { ids: r.list, rotateMin, groupMode: grouped };
    prefs.groupMode = grouped;
    writeJson('prefs.json', prefs);
    refreshTray();
  }
  return { ok: r.ok, message: r.message };
});

ipcMain.handle('idle:mode', (_e, flag) => {
  const grouped = !!flag;
  steam.setGrouped(grouped);
  prefs.groupMode = grouped;
  if (prefs.lastIdle) prefs.lastIdle.groupMode = grouped;
  writeJson('prefs.json', prefs);
  return { ok: true };
});

ipcMain.handle('idle:stop', () => {
  steam.stopIdle();
  return { ok: true };
});

ipcMain.handle('prefs:set', (_e, p) => {
  const cleaned = cleanPrefs(p);
  Object.assign(prefs, cleaned);
  writeJson('prefs.json', prefs);
  applyPrefs(Object.keys(cleaned));
  return { ok: true };
});

ipcMain.handle('ach:run', (_e, list) => {
  if (ach.running) return { ok: false, message: 'Başarım işlemi zaten sürüyor.' };
  if (steam.status !== 'ready') return { ok: false, message: 'Önce Steam’e giriş yapmalısın.' };
  const owned = new Set(steam.games.filter((g) => g.ach && !g.vac).map((g) => g.appid));
  const clean = ids(list).filter((n) => owned.has(n));
  if (!clean.length) return { ok: false, message: 'Listeden en az bir oyun seç.' };
  runAch(clean);
  return { ok: true };
});

ipcMain.handle('ach:list', async (_e, appId) => {
  const id = Number(appId);
  const game = steam.games.find((g) => g.appid === id && g.ach && !g.vac);
  if (steam.status !== 'ready' || !game) return { ok: false, message: 'Bu oyun için başarım listesi alınamadı.' };
  let meta;
  try {
    meta = await fetchAchievements(id);
  } catch (e) {
    return { ok: false, message: 'Başarım listesi Steam’den alınamadı. İnternetini kontrol et.' };
  }
  if (!meta.length) return { ok: false, message: 'Bu oyunda açılabilir başarım bulunamadı.' };
  // Yerel Steam istemcisinden mevcut açık/kapalı durumunu oku (hiçbir şeyi değiştirmez).
  const r = await runWorker(id, meta.map((m) => m.name), 'list');
  const status = new Map((r.ok && r.items ? r.items : []).map((it) => [it.name, it.unlocked]));
  return {
    ok: true,
    partial: !r.ok,
    message: r.ok ? undefined : (r.message || 'Durumlar okunamadı, hepsi açılabilir varsayıldı.'),
    items: meta.map((m) => ({ name: m.name, percent: m.percent, unlocked: status.get(m.name) || false }))
  };
});

ipcMain.handle('ach:run-some', (_e, a) => {
  if (ach.running) return { ok: false, message: 'Başarım işlemi zaten sürüyor.' };
  if (steam.status !== 'ready') return { ok: false, message: 'Önce Steam’e giriş yapmalısın.' };
  const appId = Number(a && a.appId);
  const game = steam.games.find((g) => g.appid === appId && g.ach && !g.vac);
  if (!game) return { ok: false, message: 'Bu oyun için başarım açılamıyor.' };
  const names = Array.from(new Set((a && a.names || []).map(String))).slice(0, 2000);
  if (!names.length) return { ok: false, message: 'En az bir başarım seç.' };
  runAchSome(appId, names);
  return { ok: true };
});

ipcMain.handle('ach:cancel', () => {
  ach.cancel = true;
  if (ach.child) {
    try {
      ach.child.kill();
    } catch (e) {
      /* yoksay */
    }
  }
  return { ok: true };
});

// ---- açılış ----------------------------------------------------------------------
app.whenReady().then(() => {
  migrateOld();
  prefs = Object.assign({}, DEFAULTS, cleanPrefs(readJson('prefs.json', {})));
  session.defaultSession.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
  steam.setPersonaMode(prefs.persona);
  ensureTray();
  const hidden = AUTOSTART && prefs.startHidden && !!tray;
  createWindow(!hidden);
  applyAutoStart();
  maybeAutoIdle();
});

app.on('second-instance', showWindow);
app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => {
  quitting = true;
  try {
    steam.logout();
  } catch (e) {
    /* yoksay */
  }
  if (ach.child) {
    try {
      ach.child.kill();
    } catch (e) {
      /* yoksay */
    }
  }
});
